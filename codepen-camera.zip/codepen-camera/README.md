# CodePen Camera

A Pen created on CodePen.io. Original URL: [https://codepen.io/szco/pen/bGPNWBw](https://codepen.io/szco/pen/bGPNWBw).

A simple PWA camera built using Vue, Tailwind, and WebRTC. Try adding the Debug view to your home screen and read the companion blog to learn more. 